import pkg_resources


def list_installed_packages():
    installed_packages = pkg_resources.working_set
    installed_packages_list = sorted(
        ["{}=={}".format(i.key, i.version) for i in installed_packages]
    )
    return installed_packages_list


if __name__ == "__main__":
    installed_packages = list_installed_packages()
    print("Installed Python packages:")
    for package in installed_packages:
        print(package)
